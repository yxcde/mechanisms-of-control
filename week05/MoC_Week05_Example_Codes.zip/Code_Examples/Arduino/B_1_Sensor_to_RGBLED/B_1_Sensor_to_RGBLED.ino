// Mechanisms of Control - UdK Berlin 2025 - Karsten Schuhl
// Example B_1 - Sensor to RGB LED communication

// !!! Install Adafruit NeoPixel library before using this sketch !!!

#include <Adafruit_NeoPixel.h>

#define LED_PIN    6
#define LED_COUNT  60
#define SENSOR_PIN A0 // any analog sensor or input will do (we can use a potentiometer for example)

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

void setup() {
  Serial.begin(9600);
  strip.begin();
  strip.show();
}

void loop() {
  int sensorVal = analogRead(SENSOR_PIN); // 0–1023
  Serial.println(sensorVal);
  int hue = map(sensorVal, 0, 1023, 0, 255);
  uint32_t color = Wheel(hue);

  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, color);
  }
  strip.show();
  delay(10);
}

// Fast HSV-like rainbow mapping
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) return strip.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  if(WheelPos < 170) {
    WheelPos -= 85;
    return strip.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return strip.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
