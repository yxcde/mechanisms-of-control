// Mechanisms of Control - UdK Berlin 2025 - Karsten Schuhl
// Example A_1 - Serial to RGB LED communication

// !!! Install Adafruit NeoPixel library before using this sketch !!!

#include <Adafruit_NeoPixel.h>

#define LED_PIN    6
#define LED_COUNT  60

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

String inputString = "";
bool newData = false;

void setup() {
  Serial.begin(9600);
  strip.begin();
  strip.show();
}

void loop() {
  receiveSerial();
  if (newData) {
    applyColor();
    newData = false;
  }
}

void receiveSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      newData = true;
    } else {
      inputString += c;
    }
  }
}

void applyColor() {
  int r = 0, g = 0, b = 0;

  // Split the input string by commas
  int firstComma = inputString.indexOf(',');
  int secondComma = inputString.indexOf(',', firstComma + 1);

  if (firstComma > 0 && secondComma > firstComma) {
    String rString = inputString.substring(0, firstComma);
    String gString = inputString.substring(firstComma + 1, secondComma);
    String bString = inputString.substring(secondComma + 1);

    r = rString.toInt();
    g = gString.toInt();
    b = bString.toInt();
  }

  // Set all LEDs to the received color
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
  }
  strip.show();
  inputString = "";  // Reset input buffer
}
