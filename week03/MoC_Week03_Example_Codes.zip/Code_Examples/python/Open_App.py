import serial
import subprocess

SERIAL_PORT = '/dev/tty.usbmodem141101'  # e.g., /dev/tty.usbmodem1101
BAUD_RATE = 9600

def open_textedit():
    subprocess.run(['open', '-a', 'Textedit'])

def main():
    try:
        with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1) as ser:
            print(f"Listening on {SERIAL_PORT} at {BAUD_RATE} baud...")
            while True:
                line = ser.readline().decode('utf-8').strip()
                if line:
                    print(f"Received: {line}")
                    if line == "BUTTON_PRESSED":
                        print("Opening TextEdit...")
                        open_textedit()
    except serial.SerialException as e:
        print(f"Serial error: {e}")
    except KeyboardInterrupt:
        print("Exited by user")

if __name__ == "__main__":
    main()
