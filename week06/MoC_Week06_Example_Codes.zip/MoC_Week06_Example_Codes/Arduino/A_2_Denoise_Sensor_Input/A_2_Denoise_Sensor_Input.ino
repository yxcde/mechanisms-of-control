// Mechanisms of Control - UdK Berlin Winter Semester 2025 - Karsten Schuhl
// Example A_2 - Simple threshold for sensor input to keep motor from wiggling

// ! please install the SpeedyStepper library before use !

// TASK: replace the potentiometer with another sensor (distance or similar) and 
// calibrate the threshold and mapping so that they work well

#include <SpeedyStepper.h> 

SpeedyStepper stepper;              // initialise teh SpeedyStepper library

// pin assignments
const int potPin = A0;
const int stepPin = 3;
const int dirPin = 4;

// Variables for checks and functions
const int threshold = 10;          // Minimum change in steps to trigger motion
const int maxSteps = 1600;         // Maximium number of steps for one motion
long lastTargetPosition = -1;      // Store last accepted position

void setup() {
  Serial.begin(9600);
  stepper.connectToPins(stepPin, dirPin); 
  stepper.setSpeedInStepsPerSecond(200); // set the maximum speed for the motor
  stepper.setAccelerationInStepsPerSecondPerSecond(1000); // set maximum acceleration for the motor
}

void loop() {
  int sensorValue = analogRead(potPin); // read a potentiometer 
  long targetPosition = map(sensorValue, 0, 1023, 0, maxSteps); // map the sensor values to steps

  // Check if the difference between the new targetPosition and the last one exceeds the threshold
  if (abs(targetPosition - lastTargetPosition) >= threshold) {
    stepper.moveToPositionInSteps(targetPosition);
    lastTargetPosition = targetPosition;
  }
}
