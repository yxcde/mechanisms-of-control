// Mechanisms of Control - UdK Berlin Winter Semester 2025/26 - Karsten Schuhl
// Example A_1 - Potentiometer to Stepper Motor Position

// ! please install the SpeedyStepper library before use !

#include <SpeedyStepper.h>

SpeedyStepper stepper;

// pin assignments
const int stepPin = 3;
const int dirPin = 4;
const int potPin = A0; // or use an ultrasonic sensor and convert to range

void setup() {
  stepper.connectToPins(stepPin, dirPin);
  stepper.setSpeedInStepsPerSecond(200);
  stepper.setAccelerationInStepsPerSecondPerSecond(1000);
}

void loop() {
  int sensorValue = analogRead(potPin);
  long targetPosition = map(sensorValue, 0, 1023, 0, 1600); // adjust maximum motion range here

  stepper.moveToPositionInSteps(targetPosition); // execute the motion to the target point
}
