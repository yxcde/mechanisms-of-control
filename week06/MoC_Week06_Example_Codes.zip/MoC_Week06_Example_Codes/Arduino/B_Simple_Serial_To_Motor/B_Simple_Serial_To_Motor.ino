// Mechanisms of Control at UdK Berlin New Media Class Winter Semester 2025/26 - Karsten Schuhl
// This sketch listens for simple "M:###" commands to move a stepper motor

// TASK: Implement a second command to stop the motor.

#include <SpeedyStepper.h>
SpeedyStepper stepper;

//pin assignment
const int stepPin = 3;
const int dirPin = 4;
const int ledPin = 13; 


String inputString = ""; //to hold the incoming string from the serial connection

void setup() {
  Serial.begin(9600);
  stepper.connectToPins(stepPin, dirPin);
  stepper.setSpeedInStepsPerSecond(200);
  stepper.setAccelerationInStepsPerSecondPerSecond(1000);
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      handleCommand(inputString);
      inputString = "";
    } else {
      inputString += c;
    }
  }
}

void handleCommand(String cmd) {
  if (cmd.startsWith("M:")) {   // if the string starts with "L:" 
    long steps = cmd.substring(2).toInt(); // convert the data that follows after "L:" to an integer saved as the variable state
    digitalWrite(ledPin, HIGH); 
    stepper.moveRelativeInSteps(steps);
    Serial.println("Acknowledged Motion");      // send something back to acknowledge the receipt of a command
  } else {
    Serial.println("ERR:UnknownCmd"); 
  }
}